Requirements:
	Download and Install Node.js - https://nodejs.org/en/download/ 
	Windows Operating System
	Spotify Desktop Application

Instructions:
	1. npm install
	2. node app